# Simulation script


# Required packages; 
library(ggplot2)
library(dplyr)
library(remotes)

# To run these simulations: Neutralise has to be installed 
remotes::install_github('lucp9827//Neutralise')

library(Neutralise)

# Set the working directory to NeutraliseFiles in the data folder
# Save the warking directory to object path

path = getwd()

# install/load the following packages - necessary for the data generation methods and two sample methods 
reqpkg = c("remotes","dplyr","moments","ggplot2","kSamples","lawstat","BWStest", "RVAideMemoire","DescTools","WRS2","gk","gld","twosamples")

for(i in reqpkg)
{print(i)
  print(packageVersion(i))
  #install.packages(i)
  library(i, quietly=TRUE, verbose=FALSE, warn.conflicts=FALSE, character.only=TRUE)}

# Initialise the directory

Initialise_Neutralise(path)

# Start the Neutralise function - this takes a long time, lower the simulation runs (N) to save time

Neutralise(path, N=10000)


