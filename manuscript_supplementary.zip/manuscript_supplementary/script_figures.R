# Reproduce Figurs & Results from manuscript

setwd("C:\\Users\\lucp9827\\Desktop\\manuscript_supplementary\\Data")
path = getwd()


# It is necessary to install Neutralise before this script can be ran. 
# Install Neutralise 

remotes::install_github('lucp9827//Neutralise')

# load required libraries

library(Neutralise)
library(ggplot2)
library(dplyr)


# Load summarized results - these summarized results come from the raw results of NeutraliseFiles
# These results are based on 10000 simulation runs- check simulation script for the results

load("Results_power_perdatagen.RData")
load("Results_power_perdatagen_df.RData")
load("Results_type1_perdatagen_df.RData")
load("Results_typeI_perdatagen.RData")

# Figure 2

Figure_2_top_left = Boxplot_TypeI(path,"WMW_Asymp",panel='distribution')$graph
Figure_2_top_left
Figure_2_top_right = Boxplot_TypeI(path,"TTest_VarUnequal",panel='distribution')$graph
Figure_2_top_right

Figure_2_bottom_left = Boxplot_TypeI(path,"AD",panel='distribution')$graph
Figure_2_bottom_left
Figure_2_bottom_right = Boxplot_TypeI(path,"KS",panel='distribution')$graph
Figure_2_bottom_right

# Figure 3

par.fix = data.frame(sd=3)
Figure_3=Power_curve(path,methods ='TTest_VarUnequal', data='Normal',par.fix = par.fix, alpha=0.05,CI=TRUE)
Figure_3

# Figure 4 

Figure_4_top = Power_QQ(path,"WMW_Asymp","TTest_VarUnequal",alpha=0.05,group=TRUE,N=10000)
Figure_4_top$graph
Figure_4_top$text

Figure_4_middle = Power_QQ(path,"WMW_Asymp","TTest_VarUnequal",alpha=0.05,data='Logistic',N=10000)
Figure_4_middle$graph
Figure_4_middle$text

Figure_4_down = Power_QQ(path,"AD","KS",alpha=0.05,group = TRUE,N=10000)
Figure_4_down$graph

# Figure 5

Figure_5_left= Best_method_plot(path,"TTest_VarUnequal",n=20,alpha=0.05,N=10000)
Figure_5_left$graph

Figure_5_middle= Best_method_plot(path,"WMW_Asymp",n=20,alpha=0.05,N=10000)
Figure_5_middle$graph

Figure_5_right = Best_method_plot(path,"AD",n=20,alpha=0.05,N=10000)
Figure_5_right$graph


