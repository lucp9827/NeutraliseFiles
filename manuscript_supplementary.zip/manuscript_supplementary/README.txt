Session info:

> sessionInfo()
R version 4.2.2 (2022-10-31 ucrt)
Platform: x86_64-w64-mingw32/x64 (64-bit)
Running under: Windows 10 x64 (build 19044)

Matrix products: default

locale:
[1] LC_COLLATE=Dutch_Belgium.utf8  LC_CTYPE=Dutch_Belgium.utf8    LC_MONETARY=Dutch_Belgium.utf8 LC_NUMERIC=C                  
[5] LC_TIME=Dutch_Belgium.utf8    

attached base packages:
[1] stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
 [1] twosamples_2.0.0       gld_2.6.6              gk_0.5.1               WRS2_1.1-4             DescTools_0.99.47     
 [6] RVAideMemoire_0.9-81-2 BWStest_0.2.2          lawstat_3.5            kSamples_1.2-9         SuppDists_1.1-9.7     
[11] moments_0.14.1         remotes_2.4.2          dplyr_1.1.0            ggplot2_3.4.1          Neutralise_0.1.0      

loaded via a namespace (and not attached):
 [1] tidyselect_1.2.0  lattice_0.20-45   mc2d_0.1-22       colorspace_2.0-3  vctrs_0.5.2       generics_0.1.3    expm_0.999-7     
 [8] utf8_1.2.3        rlang_1.0.6       e1071_1.7-12      pillar_1.8.1      glue_1.6.2        withr_2.5.0       readxl_1.4.1     
[15] plyr_1.8.8        lifecycle_1.0.3   rootSolve_1.8.2.3 munsell_0.5.0     gtable_0.3.1      cellranger_1.1.0  mvtnorm_1.1-3    
[22] memoise_2.0.1     labeling_0.4.2    fastmap_1.1.0     lmom_2.9          class_7.3-20      fansi_1.0.4       Rcpp_1.0.10      
[29] scales_1.2.1      cachem_1.0.6      farver_2.1.1      Exact_3.2         Kendall_2.2.1     rbibutils_2.2.13  grid_4.2.2       
[36] Rdpack_2.4        cli_3.6.0         tools_4.2.2       magrittr_2.0.3    proxy_0.4-27      tibble_3.1.8      pkgconfig_2.0.3  
[43] MASS_7.3-58.1     Matrix_1.5-3      data.table_1.14.6 reshape_0.8.9     httr_1.4.4        rstudioapi_0.14   R6_2.5.1         
[50] boot_1.3-28       compiler_4.2.2 


Scripts:

We provide two scripts to reproduce the figures in the manuscript and to reproduce the results from NeutraliseFiles. The script to reproduce the results are based on the summarized results provided in the Data folder. 
These summarized results are based on the raw results in NeutraliseFiles.
Both scripts work independently,  but need Neutralise to be installed. The installation steps for Neutralise are provided in both scripts. 

		1) script_figures.R -> To reproduce the figures from te manuscript. 
		2) script_simulation -> To regenerate the simulation results in NeutraliseFiles. 

Folder manuscript_supplementary:
		
 	- README.txt
	- script_figures.R
	- scripts_simulation.R
	- Data folder:
		
		- Summarized results files of the type I error rate and power
			1) Results_power_perdatagen.RData (list object)
			2) Results_power_perdatagen_df.RData (data frame)
			3) Results_type1_perdatagen.RData (list object)
			4) Results_typeI_perdatagen.RData
		- Settings folder which contains the parameter settings per scenario (.RData)
		- Results folder contains the raw results.
		- NeutraliseFiles directory to simulate the results. 


. 