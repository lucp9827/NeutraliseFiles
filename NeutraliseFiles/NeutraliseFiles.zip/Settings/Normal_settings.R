settings<-data.frame(
  delta=c(0,0.5,1.5,5),
  sd=c(1,2,2,2),
  null=c(1,0,0,0)
)