settings<-data.frame(
  delta=c(0,0.5,1.5,2.5),
  sd=c(1,3,3,3),
  null=c(1,0,0,0)
)