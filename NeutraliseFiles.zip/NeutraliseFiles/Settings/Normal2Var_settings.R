data.generator.name<-"Normal2var"

settings<-data.frame(
  delta=c(0,1,0,2,3),
  sd1=c(1,1,2,2,3),
  sd2=c(2,2,3,3,4),
  null=c(1,0,1,0,0)
)
